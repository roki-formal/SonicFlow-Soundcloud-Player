#!/usr/bin/env bash
# Quick local installer for SonicFlow
set -e
INSTALL_DIR="$HOME/.local/share/sonicflow"
BIN_DIR="$HOME/.local/bin"
APP_DIR="$HOME/.local/share/applications"

mkdir -p "$INSTALL_DIR" "$BIN_DIR" "$APP_DIR"
cp -r ./* "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/sonicflow-linux.sh"

ln -sf "$INSTALL_DIR/sonicflow-linux.sh" "$BIN_DIR/sonicflow"
sed -i "s|Exec=.*|Exec=$BIN_DIR/sonicflow|g" "$INSTALL_DIR/SonicFlow.desktop"
cp "$INSTALL_DIR/SonicFlow.desktop" "$APP_DIR/SonicFlow.desktop"

echo "✓ SonicFlow installed successfully to $INSTALL_DIR"
echo "  Run 'sonicflow' in terminal or launch from your application menu."
